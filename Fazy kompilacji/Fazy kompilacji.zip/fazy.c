#include <stdio.h>

#define IMIE "Maciej"
#define NAZWISKO "Dudek"

int main(void) {

	#ifdef LOOP
	
	int i, j;
	j = 1;
	
	for(i = 1; i <= 3; ++i) {
		j *= i;
	}

	printf("3! = %d\n", j);

	#endif // LOOP

	printf("Moje imie: %s\n", IMIE);
	printf("Moje nazwisko: %s\n", NAZWISKO);

	return 0;
}
